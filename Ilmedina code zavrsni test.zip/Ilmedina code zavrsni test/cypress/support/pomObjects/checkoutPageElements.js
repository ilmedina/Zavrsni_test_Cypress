const checkoutPagelokatori={
    name: '[data-test="firstName"]',
    lastname: '[data-test="lastName"]',
    postal: '[data-test="postalCode"]',
    continueButton: '[data-test="continue"]',
    checkoutButton: '[data-test="checkout"]',
    pageTitle: '[title]',
    finishButton: '[data-test="finish"]',
    pageTitleComplete: '[class="complete-header"]',
 
 }
 
 export { checkoutPagelokatori }