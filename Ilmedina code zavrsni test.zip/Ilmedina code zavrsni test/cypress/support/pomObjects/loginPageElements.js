const loginPagelokatori={
   username: '[data-test="username"]',
   password: '[data-test="password"]',
   loginButton: '[data-test="login-button"]',
   dataTestError: '[data-test="error"]',

}

export { loginPagelokatori }