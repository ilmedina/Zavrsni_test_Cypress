const cardPageLokatori= {
    cardButton: '[class="shopping_cart_link"]',
    pageTitle: '[class="header_secondary_container"]',
    cardList: '[class=cart_list]',
}

export {cardPageLokatori}