const productPagelokatori={
    productsTitle: '[class="title"]',
    menu: '[id="react-burger-menu-btn"]',
    logout: '[id="logout_sidebar_link"]',
    cardbutton: '.shopping_cart_link',
    sortConteiner: '[data-test="product_sort_container"]',
    sortConteinerItem: '[class="select_container"]',
    sortAZ: '[value="az"]',
    sortZA: '[value="za"]',
    sortLOHI: '[value="lohi"]',
    sortHILO: '[value="hilo"]',
    firstItemAZ_Add: '[data-test="add-to-cart-sauce-labs-backpack"]',
    firstItemAZ_Remove: '[data-test="remove-sauce-labs-backpack"]',
    firstItemZA_Add:'[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]',
    firstItemZA_Remove:'[data-test="remove-test.allthethings()-t-shirt-(red)"]',
    firstItemHILO_Add:'[data-test="add-to-cart-sauce-labs-fleece-jacket"]',
    firstItemHILO_Remove: '[data-test="remove-sauce-labs-fleece-jacket"]',
    firstItemLOHI_Add: '[data-test="add-to-cart-sauce-labs-onesie"]',
    firstItemLOHI_Remove:'[data-test="remove-sauce-labs-onesie"]',



    
 }
 
 export { productPagelokatori }