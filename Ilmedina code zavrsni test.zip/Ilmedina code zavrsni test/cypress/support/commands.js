// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

const cypressConfig = require("../../cypress.config");
import { loginPagelokatori } from "./pomObjects/loginPageElements";
import { productPagelokatori } from "./pomObjects/productsPageElements";
import { checkoutPagelokatori } from "./pomObjects/checkoutPageElements";
import { productPageTestData } from "../fixtures/productTestData";
Cypress.Commands.add('loginUser', (username, password)=>{
    cy.visit('/')
    cy.get (loginPagelokatori.username).type(username)
    cy.get (loginPagelokatori.password).type (password)
    cy.get (loginPagelokatori.loginButton).click()
    cy.get (productPagelokatori.productsTitle).should('have.text', productPageTestData.titleProduct)

})
    
Cypress.Commands.add('checkoutForm', (name, lastname, postal)=>{
    cy.get(checkoutPagelokatori.name).type(name)
    cy.get(checkoutPagelokatori.lastname).type(lastname)
    cy.get(checkoutPagelokatori.postal).type(postal)
    cy.get(checkoutPagelokatori.continueButton).click()

})

Cypress.Commands.add('addItemsToCart', () =>{
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemAZ)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemAZ)
        cy.get(productPagelokatori.firstItemAZ_Add).click()
        cy.get(productPagelokatori.firstItemAZ_Remove).should('have.text',productPageTestData.titleRemove)
        
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemZA)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemZA)
        cy.get(productPagelokatori.firstItemZA_Add).click()
        cy.get(productPagelokatori.firstItemZA_Remove).should('have.text', productPageTestData.titleRemove)
  
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemLOHI)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemLOHI)
        cy.get(productPagelokatori.firstItemLOHI_Add).click()
        cy.get(productPagelokatori.firstItemLOHI_Remove).should('have.text', productPageTestData.titleRemove)

        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemHILO)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemHILO)
        cy.get(productPagelokatori.firstItemHILO_Add).click()
        cy.get(productPagelokatori.firstItemHILO_Remove).should('have.text', productPageTestData.titleRemove)
    })
