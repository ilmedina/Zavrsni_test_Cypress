const loginPageTestData= {
    usernameRequired: 'Epic sadface: Username is required',
    passwordRequired: 'Epic sadface: Password is required',
    usernamePasswordUnmatch:'Epic sadface: Username and password do not match any user in this service'

}

export {loginPageTestData}