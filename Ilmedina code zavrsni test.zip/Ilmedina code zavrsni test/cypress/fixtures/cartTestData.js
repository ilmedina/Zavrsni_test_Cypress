
const cartPageTestData= {
    titleCart: 'Your Cart'

}

export {cartPageTestData}