const checkoutPageTestData= {
    titleYourInformation: 'Checkout: Your Information',
    titleOverview: 'Checkout: Overview',
    titleThankYou: 'Thank you for your order!',
}

    export{checkoutPageTestData}