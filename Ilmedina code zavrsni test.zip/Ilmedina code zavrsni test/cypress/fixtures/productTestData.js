
const productPageTestData= {
    titleProduct: 'Products',
    titleCart: 'Your Cart',
    TitleAZ: 'Name (A to Z)',
    titleZA: 'Name (Z to A)',
    titleHILO: 'Price (high to low)',
    titleLOHI: 'Price (low to high)',
    titleRemove: 'Remove',
    sortItemAZ:'az',
    sortItemZA:'za',
    sortItemLOHI:'lohi',
    sortItemHILO:'hilo',

}

export {productPageTestData}