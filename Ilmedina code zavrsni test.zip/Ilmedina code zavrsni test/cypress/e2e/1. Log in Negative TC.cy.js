
import { loginPagelokatori } from "../support/pomObjects/loginPageElements"
import { loginPageTestData } from "../fixtures/loginPageTestData"
const rightUser = Cypress.env("rightUser")
const wrongtUser = Cypress.env("wrongUser")
describe ('Log in Page - Negativni testni case-ovi', ()=> {
    it('1. Log in sa praznim username', ()=>{
        cy.visit ('/')
        cy.get (loginPagelokatori.username).clear
        cy.get (loginPagelokatori.password).type (rightUser.password)
        cy.get (loginPagelokatori.loginButton).click()
        cy.get (loginPagelokatori.dataTestError).should('have.text', loginPageTestData.usernameRequired)
    })
    
    it('2. Log in sa praznom password', ()=>{
        cy.visit ('/')
        cy.get (loginPagelokatori.username).type(rightUser.username)
        cy.get (loginPagelokatori.password).clear()
        cy.get (loginPagelokatori.loginButton).click()
        cy.get (loginPagelokatori.dataTestError).should('have.text', loginPageTestData.passwordRequired) 
    })

    it('3. Log in sa praznim password and username', ()=>{
        cy.visit ('/')
        cy.get (loginPagelokatori.username).clear()
        cy.get (loginPagelokatori.password).clear()
        cy.get (loginPagelokatori.loginButton).click()
        cy.get (loginPagelokatori.dataTestError).should('have.text', loginPageTestData.usernameRequired) 
    })
    it('4. Log in sa pogresnim passwordom', ()=>{
        cy.visit ('/')
        cy.get (loginPagelokatori.username).type(rightUser.username)
        cy.get (loginPagelokatori.password).type(wrongtUser.password)
        cy.get (loginPagelokatori.loginButton).click()
        cy.get (loginPagelokatori.dataTestError).should('have.text', loginPageTestData.usernamePasswordUnmatch) 
    })

})