const cypressConfig = require("../../cypress.config")
import { cardPageLokatori } from "../support/pomObjects/cardPageElements"
import { checkoutPagelokatori } from "../support/pomObjects/checkoutPageElements"
import { cartPageTestData } from "../fixtures/cartTestData"
import { checkoutPageTestData } from "../fixtures/checkoutTestData"
const rightUser = Cypress.env("rightUser")
describe ('Dodavanje produkata u korpu i checkout', ()=> {
    beforeEach('Otvaranje App i Login', ()=>{
        cy.loginUser (rightUser.username, rightUser.password)
    })

    it('1. Dodavanje produkata u korpu', ()=>{
        cy.wait(1000)
        cy.addItemsToCart()
        cy.get(cardPageLokatori.cardButton).click()
        cy.get(cardPageLokatori.pageTitle).should ('have.text', cartPageTestData.titleCart)
        cy.get(checkoutPagelokatori.checkoutButton).click()
        
    })
    it.only('2. Provjera broja itema u korpi', ()=>{
        cy.wait(1000)
        cy.addItemsToCart()
        cy.get(cardPageLokatori.cardButton).click()
        cy.get(cardPageLokatori.cardList).children().should('have.length', 6)
    })
    it('3. Checkout', ()=>{
        cy.wait(1000)
        cy.addItemsToCart()
        cy.get(cardPageLokatori.cardButton).click()
        cy.get(checkoutPagelokatori.checkoutButton).click()
        cy.get(cardPageLokatori.pageTitle).should ('have.text', checkoutPageTestData.titleYourInformation)
        cy.checkoutForm ('ilmedina', 'salcin', '387')
        cy.get(checkoutPagelokatori.pageTitle).should('have.text', checkoutPageTestData.titleOverview)
        cy.get(checkoutPagelokatori.finishButton).click()
        cy.get(checkoutPagelokatori.pageTitleComplete).should('have.text', checkoutPageTestData.titleThankYou)
    })     
})