const { productPageTestData } = require("../fixtures/productTestData")
const { productPagelokatori } = require("../support/pomObjects/productsPageElements")
const rightUser = Cypress.env("rightUser")

describe ('Stranica produkata', ()=> {
    beforeEach('Otvaranje App i Login', ()=>{
        //cy.visit ('/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.loginUser (rightUser.username, rightUser.password)
        })

    it('1. Provjera opcija za sortiranje', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteiner).children().should('have.length',4)
    })
            
    it('2. Sortiranje A-Z', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteinerItem).click()
        cy.get(productPagelokatori.sortAZ).should('have.text',productPageTestData.TitleAZ)
       
        
    })
    
    it('3. Sortiranje Z-A', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteinerItem).click()
        cy.get(productPagelokatori.sortZA).should('have.text',productPageTestData.titleZA)
        
     })

    it('4. Sortiranje Price (low to high)', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
         //cy.get ('[data-test="password"]').type('secret_sauce')
         //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteinerItem).click()
        cy.get(productPagelokatori.sortLOHI).should('have.text',productPageTestData.titleLOHI)
       
    })

    it('5. Sortiranje Price (high to low)', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteinerItem).click()
        cy.get(productPagelokatori.sortHILO).should('have.text',productPageTestData.titleHILO)
    
    })
        
})
