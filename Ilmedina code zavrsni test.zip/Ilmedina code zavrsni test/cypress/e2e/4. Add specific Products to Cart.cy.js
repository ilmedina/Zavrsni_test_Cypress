import { productPagelokatori } from "../support/pomObjects/productsPageElements"
import { productPageTestData } from "../fixtures/productTestData"
const rightUser = Cypress.env("rightUser")
describe ('Korpa', ()=> {
    beforeEach('Otvaranje App i Login', ()=>{
        //cy.visit ('/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.loginUser (rightUser.username, rightUser.password)
        })
            
    it('1. Dodavanje prvog proizvoda po Sortiranju A-Z', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemAZ)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemAZ)
        cy.get(productPagelokatori.firstItemAZ_Add).click()
        cy.get(productPagelokatori.firstItemAZ_Remove).should('have.text',productPageTestData.titleRemove)
        
    })
    
    it('2. Dodavanje prvog proizvoda po Sortiranju Z-A', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemZA)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemZA)
        cy.get(productPagelokatori.firstItemZA_Add).click()
        cy.get(productPagelokatori.firstItemZA_Remove).should('have.text', productPageTestData.titleRemove)
    })

    it('3. Dodavanje prvog proizvoda po Sortiranju Price (low to high)', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
         //cy.get ('[data-test="password"]').type('secret_sauce')
         //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemLOHI)
        cy.get(productPagelokatori.sortConteiner).should('have.value',productPageTestData.sortItemLOHI)
        cy.get(productPagelokatori.firstItemLOHI_Add).click()
        cy.get(productPagelokatori.firstItemLOHI_Remove).should('have.text', productPageTestData.titleRemove)

       
    })

    it('4. Dodavanje prvog proizvoda po Sortiranju Price (high to low)', ()=>{
        //cy.visit ('https://www.saucedemo.com/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.get(productPagelokatori.sortConteiner).select(productPageTestData.sortItemHILO)
        cy.get(productPagelokatori.sortConteiner).should('have.value', productPageTestData.sortItemHILO)
        cy.get(productPagelokatori.firstItemHILO_Add).click()
        cy.get(productPagelokatori.firstItemHILO_Remove).should('have.text',productPageTestData.titleRemove)
    })
        
})
