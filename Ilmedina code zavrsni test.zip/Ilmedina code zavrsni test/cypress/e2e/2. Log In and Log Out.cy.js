import { loginPagelokatori } from "../support/pomObjects/loginPageElements"
import { productPagelokatori } from "../support/pomObjects/productsPageElements"
import { productPageTestData } from "../fixtures/productTestData"
const rightUser = Cypress.env("rightUser")

describe ('Log in', ()=> {
    it('1. Uspješan Log In', ()=>{
        cy.visit ('/')
        cy.get (loginPagelokatori.username).type(rightUser.username)
        cy.get (loginPagelokatori.password).type(rightUser.password)
        cy.get (loginPagelokatori.loginButton).click()
        cy.get (productPagelokatori.productsTitle).should('have.text', productPageTestData.titleProduct)
    })
    it('2. Uspješan Log Out Products Page', ()=>{
        //cy.visit ('/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.loginUser (rightUser.username, rightUser.password)
        cy.get(productPagelokatori.menu).click()
        cy.get(productPagelokatori.logout).click()
        cy.url().should('equal', 'https://www.saucedemo.com/')

    })
    it('3. Uspješan Log Out Cart Page', ()=>{
        //cy.visit ('/')
        //cy.get ('[data-test="username"]').type('standard_user')
        //cy.get ('[data-test="password"]').type('secret_sauce')
        //cy.get ('[data-test="login-button"]').click()
        //cy.get ('[class="title"]').should('have.text', 'Products')
        cy.loginUser (rightUser.username, rightUser.password)
        cy.get(productPagelokatori.cardbutton).click()
        cy.get(productPagelokatori.productsTitle).should('have.text',productPageTestData.titleCart) 
        cy.get(productPagelokatori.menu).click()
        cy.get(productPagelokatori.logout).click()
        cy.url().should('equal', 'https://www.saucedemo.com/')


    })
})